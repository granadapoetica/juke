  var porta            = 3002;
  var bandaSelecionada = undefined;
  var lstMusicas       = [];
  var dados            = [];
  
  function buscarBandas(){
    var request = $.ajax(
	{
		url: 'http://localhost:'+ porta +'/bandas',
		method: "GET",	  
		dataType: "json"		  
	}); 
	request.done(function(result)
	{	    		   		  
		$('#selBandas').append($('<option>', 
		{
			value: -1,
			text: '-'
		}));
		debugger;
	    for(var i=0; i< result.length;i++)
	      adicionaBanda(i,result[i].Nome);           
	}); 	
	request.fail(function( jqXHR, textStatus){
		  alert('Erro ao ler o end point de Albuns');
	});          
  } 	
  function configurando(){
	var request = $.ajax(
	{
		url: 'http://localhost:'+ porta +'/configurando/',
		method: "POST",	  
		dataType: "json",
		data: { "Banda": bandaSelecionada }
	}); 
	request.done(function(result)
	{
		this.dados = result; 
		carregar(result);
	}); 
	request.fail(function( jqXHR, textStatus ){
	      alert('Erro ao ler o end point de Albuns');
	}); 
  } 
  function detalhesAlbum(){
	  
	/*$('#txtNomeAlbum')[0].value  = dados.Albuns[0].Album; 
	$('#txtDetalhesAlbum')[0].value  = dados.Albuns[0].detalhes;
	getSelecionado();	
	//document.getElementById("imgBanda").value = dados.ImgBanda;		
	//document.getElementById("imgAlbum").value = dados.Albuns[0].CapaAlbum;	
	//$('#selAlbuns').empty();
	//$('select>option:eq(0)').prop('selected', true);*/  	  	  
  }
  function carregar(result){
	debugger; 
	$('#txtDescricaoBanda')[0].value = result.Banda;	
	$("#divMusicas").empty();	
	getSelecionado();	
  } 
  function verificaMapaExiste(){
	bandaSelecionada = $("#selBandas option:selected").text();
	var request = $.ajax(
	{
		url: 'http://localhost:'+ porta +'/mapaexiste/',
		method: "POST",	  
		dataType: "json",
		data: { "Banda": bandaSelecionada }
	}); 
	request.done(function(result)
	{
		if(result.resultado === "OK"){
		   if(confirm('Esta banda já está configurada, deseja atualizar?'))
			  configurando();		    		
		}else{
			getSelecionado();			
		} 
	}); 
	request.fail(function( jqXHR, textStatus ){
	      alert('Erro ao ler o end point de Albuns');
	});    	  
  }
  function getSelecionado(){
	bandaSelecionada = $("#selBandas option:selected").text();
	var request = $.ajax(
	{
		url: 'http://localhost:'+ porta +'/album/',
		method: "POST",	  
		dataType: "json",
		data: { "Banda": bandaSelecionada }
	}); 
	request.done(function(result)
	{
		// limpar();
		$('#selAlbuns').append($('<option>', {   value: -1,   text: '-'	}));		    			
		
		for(var i=0; i< result.length;i++)	
		  adicionaAba(i,result[i]);         
	}); 
	request.fail(function( jqXHR, textStatus ) {
	    alert('Erro ao ler o end point de Albuns');
	});  
  }
  
  function adicionaBanda(i , nomeBanda){
	$('#selBandas').append($('<option>', 
	{
		value: i,
		text: nomeBanda
	}));	  
  }  
  
  function getMusicasSelecionadas(){	
	var albumSelecionado = $("#selAlbuns option:selected").text();	
	var request = $.ajax(
	{
		url: 'http://localhost:'+ porta +'/musicas?Banda=' + bandaSelecionada +'&NomeAlbum='+ albumSelecionado ,
		method: "POST",	  
		dataType: "json",
		data: { "album": albumSelecionado }
	}); 
	request.done(function(result)
	{
		$("#divMusicas").empty();
		var list = $("#divMusicas").append("<ul class=\"list-group\"></ul>");
			list.append("<li class=\"\list-group-item active\"> Banda: "+ bandaSelecionada + " - Album:"+ albumSelecionado  +"</li>");	
						
		var musicas = [];		
		if(result.A === 1)  
			musicas = result; 
		else
			musicas = result.Musicas; 					 
		
		for (var i = 0; i < result.Musicas.length; i++){			  	   
			list.append("<li>Musica Numero:"+ i +"<input id=\"txtMusica"+ i +"\" type=\"text\"></li>");
			lstMusicas.push({ "Track": albumSelecionado + "/"+ result[i], "indice": "txtMusica"+ i , "Mestre" : ""});  
		}		         
	}); 
	request.fail(function( jqXHR, textStatus ) {
	  alert('Erro ao ler o end point de Albuns');
	});	
  }
  function salvar(){
	  
	for (var i =0;i < lstMusicas.length; i++)
		lstMusicas[i].Mestre = $('#'+lstMusicas[i].indice)[0].value;
		
	var request = $.ajax(
	{
		url: 'http://localhost:'+ porta +'/gravar',
		method: "POST",	  
		dataType: "json",
		data: 
		{ 
			"nomeBanda" : bandaSelecionada,
			"imgBanda"  : $('#imgBanda')[0].files.length === 0 ? './Repositorio/banda.jpg' : $('#imgBanda')[0].files[0].name,
			"detalheBanda": $('#txtDescricaoBanda')[0].value,
			"Albuns":
			[{
				"Album"    : $('#txtNomeAlbum')[0].value,    
				"CapaAlbum": $('#imgAlbum')[0].files.length === 0 ? './Repositorio/disco.jpg' : $('#imgAlbum')[0].files[0].name,
				"detalhes" : $('#txtDetalhesAlbum')[0].value,
				"Musicas"  : lstMusicas				
			}]	
		}
	}); 
	request.done(function(result)
	{
		alert(result.resultado); 
		limpar();
	}); 
	request.fail(function( jqXHR, textStatus ) {
	  alert('Erro ao ler o end point de Albuns');
	});
  }
  function adicionaAba(i,Album){
	$('#selAlbuns').append($('<option>', 
	{
		value: i,
		text: Album
	}));
  }   	  
  function limpar(){
	$('#txtDescricaoBanda')[0].value = '';
	$('#txtNomeAlbum')[0].value      = ''; 
	$('#txtDetalhesAlbum')[0].value  = '';
	$("#divMusicas").empty();
	document.getElementById("imgBanda").value = "";		
	document.getElementById("imgAlbum").value = "";	
	$('#selAlbuns').empty();
	$('select>option:eq(0)').prop('selected', true);  	  
  }		
  
  $(document).ready(function()
  {
	buscarBandas();	
  });  
$(function() {
  $('#player').toggleClass('show');
});


$('.menu').click(function() {
  $('#player').toggleClass('show');
});

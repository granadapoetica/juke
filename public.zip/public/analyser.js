  var porta = 3002;
  function buscarBandas(){
    var request = $.ajax({
		  url: 'http://localhost:'+ porta +'/bandas',
		  method: "GET",	  
		  dataType: "json"
		}); 
		request.done(function(result){	    
		   console.log(result);
		   var list = $("#divResultados").append("<ul class=\"list-group\"></ul>");
		   list.append("<li class=\"\list-group-item active\"> Bandas </li>");	
		
			var array = result;	
	
			for (var i = 0; i < array.length; i++){		
				list.append("<li class=\"\list-group-item\">"+ array[i].Banda +" <input type=\"button\" value=\"Detalhes\" onClick=\"redireciona('"+ array[i].Detalhes +"')\"></li>");		
			}
		    debugger;          
		}); 
		request.fail(function( jqXHR, textStatus ) {
		  alert('Erro ao ler o end point de Albuns');
	});          
  } 	
  function adicionaAba(NomeAlbum){
	var nextTab = $('#tabs li').length +1;	
	$('<li><a href="#tab'+nextTab+'" data-toggle="tab">Tab '+nextTab+'</a></li>').appendTo('#tabs');
	
	$('<div class="tab-pane" id="tab'+nextTab+'">' + NomeAlbum +' content</div>').appendTo('.tab-content');
	$('#tabs a:last').tab('show');    
  } 
  
  $('#btnAdd').click(function (e){
		adicionaAba();
   });
	
  $( document ).ready(function()
  {
	buscarBandas();
  });

  function redireciona(rota){
	alert(rota);	  
  }    
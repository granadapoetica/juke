  var gabarito       = [];
  var contVariavel   = 0;
  var nivel          = 0;
  var porta          = 3008;
  var LetraCorrente  = '';
  var AlbumCorrente  = '';
  var BandaCorrente  = '';
  var socket         = io("http://localhost:"+ porta);
  var contadorDiv    = 0;

  $( document ).ready(function()
  {
	 iniciaGeral();
  });
  
  function iniciaGeral(){
     nivel          = 0;
     gabarito = geraAlfabeto();
     explodeGabarito();
     $('#player').toggleClass('show');
	 iniciaWebCam();
  }
  function iniciaWebCam(){
	window.qrcodeScanner = new QRCodeScanner({ rootSelector: "#qrcode-scanner" });  
		qrcodeScanner.open((err, result) => {
		   carregaAlbumPorId(result.data);	
    });
    qrcodeScanner.startWebcam(this);      	  
  }
  
  function envia(msg)
  {
	socket.emit('messageBroadcast',msg);
  }

  socket.on('messageBroadcast', function(msg)
  {
	 switch(msg){
		case "descer"   : desceNivel(); break;
		case "subir"    : subirNivel(); break;
        case "avancar"  : avancaAlfabeto(); break;
		case "retornar" : retornaAlfabeto(); break;
        case "tocar"    : tocar();break;
        case "playlist" : mostrarPlayList();break;
        case "maximizar": maximizar();break;
        case "pular"    : avancarMusica();break;             
	 }
  });
  function tocarMusica(){
	console.log('Música:',gabarito[contVariavel]);
	try{
		adicionaMusica(gabarito[contVariavel]);
	}catch(e){
		$('#txtTelemetria').text('Erro ao ler o video:'+ gabarito[contVariavel].Mestre);
 	}
  }
  function tocarAlbunsBanda(){
	if (confirm('Deseja tocar os albuns de' + gabarito[contVariavel].mestre + '?')){
		for(var i=0 ; i < gabarito[contVariavel].Albuns.length;i++)
			for(var j = 0;j <  gabarito[contVariavel].Albuns[i].Musicas.length;j++)
		        listaMusicas.push(gabarito[contVariavel].Albuns[i].Musicas[j].Track);
	    
        verificaLista();	    
    }
  }
  function carregaAlbumPorId(IdAlbum){
	gabarito = geraGabarito('Musicas',IdAlbum,true);	
  } 
  function tocaTodasAlbum(){
	for(var j = 0;j <  gabarito.length;j++)
		listaMusicas.push(gabarito[j]);
	            
    if(!musicaTocando) 
       verificaLista();
  }
  function tocarTodasMusicasAlbum(){
	if (confirm('Deseja tocar as músicas de ' + gabarito[contVariavel].mestre + '?'))        
	   tocaTodasAlbum();     
  }
  function tocarPlayList(){
      var request = $.ajax({
		  url: 'http://localhost:'+ porta +'/PlayList',
		  method: "GET",	  
		  dataType: "json"
		}); 
		request.done(function(result){	    
		   console.log(result);
		   contVariavel = 0;
           for(var i=0;i < result.length;i++){
              var teste = result[i]; 
              for(var j=0;j < teste.length;j++){  
                 listaMusicas.push(teste[j]);  
              }
           }
           $('#txtTelemetria').text('PlayList full carregada');           
           verificaLista();          
		}); 
		request.fail(function( jqXHR, textStatus ) {
		  $('#txtTelemetria').text('Erro ao ler o end point de Albuns');
	  });          
  }
  
  function tocarQuandoAcabar(){      
      listaMusicas.reverse();
      listaMusicas.push(gabarito[contVariavel]);
      listaMusicas.reverse();
  }
  function tocar(){
        switch(nivel){
            case 1: tocarAlbunsBanda(); break;
            case 2: tocarTodasMusicasAlbum(); break;
            case 3: tocarMusica(); break;
        }
  }

  function desceNivel(){
        if((nivel + 1) < 4)	
            nivel++;		
        
        switch(nivel){
            case 0:  gabarito = geraAlfabeto();	  break; 
            case 1:  gabarito = geraGabarito('Bandas',gabarito[contVariavel].mestre,false ); break;
            case 2:  gabarito = geraGabarito('Albuns',gabarito[contVariavel]._id,false); break;	
            case 3:  gabarito = geraGabarito('Musicas',gabarito[contVariavel]._id,false ); break;			
        } 			
  } 
  function subirNivel(){
        if((nivel - 1) >= -1)	
            nivel--;	
        
        switch(nivel){
            case 0:  gabarito = geraAlfabeto(); explodeGabarito(); break; 
            case 1:  gabarito = geraGabarito('Bandas',LetraCorrente,false); break;
            case 2:  gabarito = geraGabarito('Albuns',AlbumCorrente,false); break;	        			
        } 			
  }

  function geraGabarito(rota,parametro,tocar){		
		switch(rota)
		{
			case "Bandas": LetraCorrente = parametro; break; 	
			case "Albuns": AlbumCorrente = parametro; break; 		
		}
		
		var request = $.ajax({
		  url: 'http://localhost:'+ porta +'/'+ rota +'?parametro='+ parametro,
		  method: "POST",	  
		  dataType: "json"
		}); 
		request.done(function(result){	    
		   console.log(result);
		   contVariavel = 0;
		   gabarito = result;	   
		   explodeGabarito();	
		   if(tocar)
			  tocaTodasAlbum(); 		    
		}); 
		request.fail(function( jqXHR, textStatus ) {
		  $('#txtTelemetria').text('Erro ao ler o end point de Albuns');
		});  
   }

   function avancaAlfabeto(){     
		if((contVariavel + 1) >= gabarito.length)
			contVariavel = 0;  
		else 
			contVariavel++;      	
		
		explodeGabarito();
   }
   function retornaAlfabeto(){
        if((contVariavel - 1) <= -1)
            contVariavel = gabarito.length-1;  
        else 
            contVariavel--;   

        explodeGabarito();	
   }  
   function explodeGabarito(){
        if(nivel === 3)
        {		 
            if(contVariavel >= 5)			
            $('#playlist').animate({scrollTop: $('#playlist').prop("scrollHeight")}, 500);		  
            
            if((contVariavel + 1) >= gabarito.length) 					
            $('#playlist').animate({ scrollTop: "0" }, 10); 
                
            $("#detalhes").hide();
            $("#imgMestre").hide();
            $("#playlist").empty();		
            $("#playlist").show();
                    
            for(var i=0;i < gabarito.length;i++)
				$("#playlist").append('<li class="list-group-item" id="'+ gabarito[i]._id +'">'+ gabarito[i].mestre + '</li>');		 
                        
            for(var j=0;j < gabarito.length;j++){
                document.getElementById(gabarito[j]._id).style.backgroundColor = 'black';  
                document.getElementById(gabarito[contVariavel]._id).style.backgroundColor = 'green' ; 
            }
            $("#divPlayList").show();
            $("#divImg").hide();		
        }else{	
            $("#divPlayList").hide();
            $("#divImg").show();
            $("#imgMestre").show();
            $("#detalhes").show();
            
            $("#mestre").text(gabarito[contVariavel].mestre);   
            $("#detalhes").text(gabarito[contVariavel].detalhes);	 		 			 	    
            $("#imgMestre").attr("src",gabarito[contVariavel].imgMestre);
        }
  }

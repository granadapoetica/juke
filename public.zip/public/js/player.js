var listaMusicas   = [];
var musicaTocando  = false; 
var musicaCorrente = undefined;
var media          = undefined;  
var porta          = 3008; 
var modoPlayList   = false; 
var maximizado     = false;

$(document).ready(function(){
	inicializaPlayer();
	console.log('Player Inicializado'); 
});  

function inicializaPlayer(){
	media=document.getElementById("playerDeVideo");	
	$("#playerDeVideo").hide(); 	
	media.addEventListener('ended', (event) => 
	{
		verificaLista();
	});	
} 
function voltarTelaAoNormal(){    
    elem = media; 
    elem.exitFullscreen();    
}

function maximizar(){    
    if(maximizado){
       voltarTelaAoNormal();         
    }else{        
        elem = media; 
        if (elem.requestFullscreen) {        
            elem.requestFullscreen();        
        } else if (elem.mozRequestFullScreen) {            
            elem.mozRequestFullScreen();       
        } else if (elem.webkitRequestFullscreen) {            
            elem.webkitRequestFullscreen();
        } else if (elem.msRequestFullscreen) {             
            elem.msRequestFullscreen();
        }
    }
}
function adicionaMusica(musica){	
	if(musicaTocando)
    {
		$('#txtTelemetria').text('Musica:'+ musica.mestre + ' adicionada!'); 
		listaMusicas.push(musica); 
	}else{
		tocaMusica(musica);		
	}  		
}
function verificaLista(){
	if(listaMusicas.length > 0)
	{	
       musicaCorrente =  listaMusicas.pop();
	   tocaMusica(musicaCorrente);
	}else{
        musicaTocando = false;
    }  	
}
function avancarMusica(){
    if(modoPlayList){
       if (confirm('Deseja pular a musica atual?'))
       {
            musicaCorrente =  listaMusicas.pop();
            tocaMusica(musicaCorrente);
       }     
    }     
}
function mostrarPlayList(){
	if(!modoPlayList){ 	  
	  atualizaPlayList();	
	  $("#divPlayList").show();
      $("#divImg").hide();
	  modoPlayList = true; 		  	            	  
	}else{
	  $("#divPlayList").hide();
      $("#divImg").show();	
	  iniciaGeral();
      modoPlayList = false;	  	  	  
	} 
}

function atualizaPlayList(){
    $("#playlist").empty();	  

	for(var i= listaMusicas.length -1 ;i >= 0;i--)
        $("#playlist").append('<li class="list-group-item">'+ listaMusicas[i].mestre + '</li>');	                  
}

function tocaMusica(musica){	
	$('#txtTelemetria').text('Tocando:' + musica.mestre);  	
	$("#playerDeVideo").show(); 	
	musicaCorrente = musica;  
	media.removeAttribute("src"); 
	media.setAttribute('src', 'http://localhost:'+ porta +'/video?parametro='+ musica.Track);	
	media.pause();		
	media.load();  
	media.play();	   	
	musicaTocando = true; 
    if(modoPlayList)       
       atualizaPlayList();    
}

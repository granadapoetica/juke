$(function() {
  $('#player').toggleClass('hide');
});

$('.menu').click(function() {
  $('#player').toggleClass('show');
});

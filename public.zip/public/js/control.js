  var socket = io();
  $( document ).ready(function()
  {
	 $('#txtModulos').val('{noite}');
  });
  
  function envia(msg)
  {
	socket.emit('messageBroadcast',msg);					
  }	  
  socket.on('messageBroadcast', function(msg)
  { 	
       console.log('msg:',msg);   						
  });	  

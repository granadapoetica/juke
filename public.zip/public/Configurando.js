  var porta            = 3008;
  var bandaSelecionada = undefined;  
  var AlbumSelecionado = undefined;
  var Mapa; 
  
  function buscarBandas(){
    var request = $.ajax(
	{
		url: 'http://localhost:'+ porta +'/bandas',
		method: "GET",	  
		dataType: "json"		  
	}); 
	request.done(function(result)
	{	    		   		  
		carregaCombo('#selBandas',result); 		
	}); 	
	request.fail(function( jqXHR, textStatus){
		debugger;   
        alert('Erro ao ler o end point de Bandas' + jqXHR);
	});          
  }
  function CarregaAlbuns(){	
	bandaSelecionada = $("#selBandas option:selected").text();
    console.log(bandaSelecionada); 
	var request = $.ajax(
	{
		url: 'http://localhost:'+ porta +'/configurando?Banda='+ bandaSelecionada,
		method: "POST",	  
		dataType: "json"		
	}); 
	request.done(function(result)
	{		
		Mapa = result;
		carregaCombo('#selAlbuns',Mapa.Albuns);		
	}); 
	request.fail(function( jqXHR, textStatus ){
	      alert('Erro ao ler o end point de Albuns');
	}); 
  }     
  function carregaCombo(nomeCombo, arrayDados){
	$(nomeCombo).empty();
	$(nomeCombo).append($('<option>', 
	{
			value: -1,
			text: '-'
	}));		  
	for(var i=0; i< arrayDados.length;i++){
		console.log(arrayDados[i].Nome); 
        $(nomeCombo).append($('<option>', 
		{
			value: i,
			text: arrayDados[i].Nome
		}));	  
	}	  
  }      	  
  function getMusicasSelecionadas(){		
	this.AlbumSelecionado = Mapa.Albuns.filter(el => el.Nome === $("#selAlbuns option:selected").text())[0];
	$("#divMusicas").empty();
	var list = $("#divMusicas").append("<ul class=\"list-group\"></ul>");
		list.append("<li class=\"\list-group-item active\"> Banda: "+ Mapa.Banda + " - Album:"+  this.AlbumSelecionado.Nome +"</li>");	
	
	for (var i = 0; i < this.AlbumSelecionado.Musicas.length; i++)			  	   
		list.append("<li>Musica Numero:"+ i +"<input id=\"txtMusica"+ i +"\" type=\"text\" /></li>");			
	
	for (var i = 0; i < this.AlbumSelecionado.Musicas.length; i++)			  	   
		$('#txtMusica'+ i).val(this.AlbumSelecionado.Musicas[i].Mestre);	
  }
  function salvar(){					
	for (var i = 0; i < Mapa.Albuns.length; i++)
		if(Mapa.Albuns[i].Nome === this.AlbumSelecionado.Nome)		 
			for (var j = 0; j < Mapa.Albuns[i].Musicas.length; j++)					
				Mapa.Albuns[i].Musicas[j].Mestre = $('#txtMusica'+ j).val();					

    bandaSelecionada = $("#selBandas option:selected").text();
    var request = $.ajax(
	{
		url: 'http://localhost:'+ porta +'/gravar?Mapa='+ JSON.stringify(this.Mapa) + '&BandaSel='+ bandaSelecionada ,
		method: "post",	  		
        contentType: "application/json; charset=utf-8",
        traditional: true,
		data: 
		{ 
			"Mapa" : JSON.stringify(this.Mapa)			
		}
	}); 
	request.done(function(result)
	{		
		alert("Salvo com sucesso!" +result); 
	}); 
	request.fail(function( jqXHR, textStatus ) {
	  alert('Erro ao ler o end point de Albuns');
	});
  }
  
  $(document).ready(function()
  {
	buscarBandas();	
  });  

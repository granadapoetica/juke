  var socket = io();
  var etapa = 0; 	  
  var fimPaginacao = 0;   	  	  
  var lstCommand = [];	  
  var topicosGeral = [];
  var contador = 0;   
  
  $( document ).ready(function()
  {
	$('#txtModulos').val('{}');
  });
  
  function iniciarCrawler(inicio)
  {
	$('#iniciarCrawler').text('Aguarde...'); 
	$('#iniciarCrawler').prop("disabled", true); 					
	try{
		if($('#txtModulos').val() === '')
		{
			throw('Você precisa inserir algum json na caixa de texto');
		}else{		
			lstCommand.push("prepare a agua");
			lstCommand.push("ligue o fogao");
			lstCommand.push("coloque a agua no fogao");
			lstCommand.push("FIM");			
			interarCrawler(inicio);
		}		
	}catch(exception){
		alert(exception); 			
		$('#iniciarCrawler').text('Iniciar'); 
		$('#iniciarCrawler').prop("disabled", false); 			
	} 				
  }	  
  function interarCrawler(inicio)
  {
	//console.log(lstCommand[inicio]); 
	fim = lstCommand.length; 
	socket.emit('messageBroadcast',lstCommand[inicio]);		
	inicio = inicio + 1; 		
		
	if(inicio < lstCommand.length)
	   interarCrawler(inicio);		        				
  }  
  socket.on('messageBroadcast', function(msg)
  { 		
	if((msg ==='FIM'))
	{			
		$('#iniciarCrawler').text('Iniciar'); 
		$('#iniciarCrawler').prop("disabled", false); 					 	  			
		filtraRetornos();
	}			  
	topicosGeral.push(msg); 							
  });	  
  function filtraRetornos()
  {	
	$('#iniciarCrawler').text('Carregando os resultados'); 
	var list = $("#divResultados").append("<ul class=\"list-group\"></ul>");
		list.append("<li class=\"\list-group-item active\">Bora !!!!!! </li>");	
	
	for(var i = 0; i< topicosGeral.length;i++)			
	   list.append("<li class=\"\list-group-item\">"+ topicosGeral[i] +"</li>");				
  }	  